import AnimationConcepts from "@/components/admin/AnimationConcepts";

export default function AnimationConceptsPage() {
  return <AnimationConcepts />;
}
