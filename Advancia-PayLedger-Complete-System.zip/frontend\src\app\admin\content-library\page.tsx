import ContentLibrary from "@/components/admin/ContentLibrary";

export default function ContentLibraryPage() {
  return <ContentLibrary />;
}
