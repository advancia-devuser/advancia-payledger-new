import DebuggingSelfAudit from "@/components/DebuggingSelfAudit";

export default function DebuggingAuditPage() {
  return <DebuggingSelfAudit />;
}
