import DebuggingInfraImplementation from "@/components/DebuggingInfraImplementation";

export default function DebuggingImplementationPage() {
  return <DebuggingInfraImplementation />;
}
