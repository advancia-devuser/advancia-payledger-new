import DebuggingInfrastructurePlan from "@/components/DebuggingInfrastructurePlan";

export default function DebuggingInfrastructurePage() {
  return <DebuggingInfrastructurePlan />;
}
