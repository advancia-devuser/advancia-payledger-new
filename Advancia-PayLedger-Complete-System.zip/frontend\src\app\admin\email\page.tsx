import EmailService from "@/components/EmailService";

export default function EmailAdminPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <EmailService />
    </div>
  );
}
