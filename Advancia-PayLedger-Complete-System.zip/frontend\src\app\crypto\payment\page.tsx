import CryptoPayment from "@/components/payment/CryptoPayment";

export default function CryptoPaymentPage() {
  return <CryptoPayment />;
}
