import ProductNarratives from "@/components/ProductNarratives";

export default function NarrativesPage() {
  return <ProductNarratives />;
}
