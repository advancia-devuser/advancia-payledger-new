export default function TestPage() {
  return (
    <div style={{ padding: '50px', textAlign: 'center' }}>
      <h1>Test Page Works!</h1>
      <p>If you see this, Next.js routing is working correctly.</p>
      <a href="/crypto/purchase">Go to Crypto Purchase</a>
    </div>
  );
}
